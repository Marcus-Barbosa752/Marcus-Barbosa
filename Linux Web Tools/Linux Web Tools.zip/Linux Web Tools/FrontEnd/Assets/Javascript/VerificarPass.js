const InputPass = document.querySelectorAll('.InputKeyCode')
const BtnNaoTenhoConta = document.getElementById('BtnNaoTenhoConta')
const BtnSubmitLogin = document.getElementById('BtnSubmitLogin')
const MessageBox_VerificarPass = document.getElementById('MessageBox')

// Captura o código digitado
function pegarCodigoDigitado() {
    return Array.from(InputPass).map(input => input.value).join('')
}

// Exibe mensagem
function mostrarMensagem(texto, corFundo, corTexto) {
    MessageBox_VerificarPass.textContent = texto
    MessageBox_VerificarPass.style.background = corFundo
    MessageBox_VerificarPass.style.color = corTexto
    MessageBox_VerificarPass.style.top = '10px'
    setTimeout(() => { MessageBox_VerificarPass.style.top = '-50px' }, 5000)
}

// Enviar código por e-mail
function enviarCodigo() {
    const email = document.getElementById('InputEmail').value

    if (!email) {
        mostrarMensagem('Digite um e-mail válido!', '#f62913', '#fff')
        return
    }

    fetch('http://localhost:8080/enviar-codigo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            mostrarMensagem('Código enviado com sucesso!', '#51bc42', '#000')
        } else {
            mostrarMensagem(data.message, '#f62913', '#fff')
        }
    })
    .catch(() => {
        mostrarMensagem('Erro ao enviar o código!', '#f62913', '#fff')
    })
}

BtnSubmitLogin.addEventListener('click', (e) => {
    e.preventDefault()
    enviarCodigo()
})

BtnNaoTenhoConta.addEventListener('click', (e) => {
    e.preventDefault()
    enviarCodigo()
})

InputPass.forEach((input, index) => {
    input.addEventListener('input', () => {
        if (input.value && InputPass[index + 1]) InputPass[index + 1].focus()
    })

    input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !input.value && InputPass[index - 1]) {
            InputPass[index - 1].focus()
        }
    })
})
