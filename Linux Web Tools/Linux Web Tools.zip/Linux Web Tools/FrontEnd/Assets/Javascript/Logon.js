const MessageBox = document.getElementById("MessageBox")
const InputKeyCode = document.querySelectorAll('.InputKeyCode')
const InputEmail = document.getElementById('InputEmail')

const MessageBox_Settings = {
    Ok: { Background: '#51bc42', Color: "#000" },
    Erro: { Background: "#f62913", Color: "#fff" }
}

const Show_MessageBox = (Objeto = null, Background = null, Color = null, Texto = null) => {
    if (!Objeto || !Background || !Color || !Texto) return

    Objeto.textContent = Texto
    Objeto.style.background = Background
    Objeto.style.color = Color

    setTimeout(() => {
        Objeto.style.top = "10px"
    })

    setTimeout(() => {
        Objeto.style.top = '-50px'
    }, 5000)
}

const Message_Box = (Status, Texto) => {
    switch (Status) {
        case "Sucesso":
            Show_MessageBox(MessageBox, MessageBox_Settings.Ok.Background, MessageBox_Settings.Ok.Color, Texto)
            break
        case "Erro":
            Show_MessageBox(MessageBox, MessageBox_Settings.Erro.Background, MessageBox_Settings.Erro.Color, Texto)
            break
    }
}

// Função para coletar o código digitado nos inputs
const ObterCodigoDigitado = () => {
    return Array.from(InputKeyCode).map(input => input.value).join('')
}

// Função para validar no backend
const Validar_Codigo_No_Backend = () => {
    const codigo = ObterCodigoDigitado()
    const email = InputEmail.value

    if (!email || !codigo) {
        Message_Box('Erro', 'Preencha o e-mail e todos os campos do código!')
        return
    }

    fetch('http://localhost:8080/validar-codigo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email, codigoDigitado: codigo })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Message_Box('Sucesso', data.message)

            setTimeout(() => {
                window.location.href = '/Index.html'
            }, 1000)

        } else {
            Message_Box('Erro', data.message)
        }
    })
    .catch(error => {
        console.error('Erro ao validar o código:', error)
        Message_Box('Erro', 'Erro na comunicação com o servidor!')
    })
}

// Eventos nos inputs do código
InputKeyCode.forEach((Input, Index) => {
    Input.oninput = () => {
        if (!Input.value) {
            const BackInput = InputKeyCode[Index - 1]
            if (BackInput) BackInput.focus()
            return
        }

        const ProximoInput = InputKeyCode[Index + 1]
        if (ProximoInput) ProximoInput.focus()

        const InputsPreenchidos = Array.from(InputKeyCode).every(input => input.value)

        if (InputsPreenchidos) {
            Validar_Codigo_No_Backend()
        }
    }

    Input.onkeydown = (e) => {
        if (e.key === 'Backspace' && !Input.value) {
            const BackInput = InputKeyCode[Index - 1]
            if (BackInput) BackInput.focus()
        }
    }
})