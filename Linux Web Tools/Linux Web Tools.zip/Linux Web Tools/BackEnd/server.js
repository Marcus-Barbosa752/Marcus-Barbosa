const express = require('express')
const nodemailer = require('nodemailer')
const cors = require('cors')
const path = require('path')
require('dotenv').config()

const app = express()
const port = 8080

app.use(cors())
app.use(express.json())

const FrontEndPath = path.join(__dirname, '..', 'FrontEnd')
app.use(express.static(FrontEndPath))

app.get('/', (req, res) => {
    res.sendFile(path.join(FrontEndPath, 'Assets/Pages/Logon.html'))
})

let codigoGerado = ''
let emailDestino = ''

function gerarCodigo() {
    return Math.floor(100000 + Math.random() * 900000).toString()
}

app.post('/enviar-codigo', async (req, res) => {
    const { email } = req.body

    if (!email) {
        return res.status(400).json({ success: false, message: 'Email não informado.' })
    }

    emailDestino = email
    codigoGerado = gerarCodigo()

    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    })

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: emailDestino,
        subject: 'Seu código de verificação',
        html: `<p>Seu código de verificação é: <b>${codigoGerado}</b></p>`
    }

    try {
        await transporter.sendMail(mailOptions)
        console.log(`Código ${codigoGerado} enviado para ${emailDestino}`)
        res.json({ success: true, message: 'Código enviado com sucesso!' })
    } catch (error) {
        console.error('Erro ao enviar o email:', error)
        res.status(500).json({ success: false, message: 'Erro ao enviar o código por e-mail.' })
    }
})

app.post('/validar-codigo', (req, res) => {
    const { email, codigoDigitado } = req.body

    if (!email || !codigoDigitado) {
        return res.status(400).json({ success: false, message: 'Email e código são obrigatórios.' })
    }

    if (email !== emailDestino) {
        return res.status(400).json({ success: false, message: 'Email não confere com o destinatário do código.' })
    }

    if (codigoDigitado === codigoGerado) {
        res.json({ success: true, message: 'Código correto! Login efetuado!' })
    } else {
        res.status(400).json({ success: false, message: 'Código incorreto.' })
    }
})

app.listen(port, () => {
    console.log(`Servidor rodando em: http://localhost:${port}`)
})
